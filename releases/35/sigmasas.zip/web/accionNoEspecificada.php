<div>
	<h2>Acceso denegado</h2>
	<p>Ustéd no ha especificado ninguna acción</p>
</div>