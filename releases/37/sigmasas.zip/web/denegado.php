<div>
	<h2>Acceso denegado</h2>
	<p>Ustéd no está autorizado para ingresar a este sitio</p>
</div>